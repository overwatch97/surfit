package com.example.apoorv.surfit;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Intent;
import android.net.Uri;
import android.net.http.SslError;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    historydb db;
    historydb bm;
    private EditText editText;
    private Button button;
    private android.webkit.WebView WebView;
    private Button Menu_Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText) findViewById(R.id.entrurl);
        button =(Button)findViewById(R.id.button);
        WebView = (android.webkit.WebView) findViewById(R.id.webView);
        WebView.getSettings().setBuiltInZoomControls(true);
        WebView.getSettings().setDisplayZoomControls(false);
        db = new historydb(this);
        button.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetJavaScriptEnabled")
            @Override
            public void onClick(View v) {
                String url =editText.getText().toString();
                db.AddHistory(url);
                WebView.getSettings().setLoadsImagesAutomatically(true);
                WebView.getSettings().setJavaScriptEnabled(true);
                WebView.getSettings().getBuiltInZoomControls();
                WebView.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
                /* to load ofline cache */
                WebView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
                WebView.getSettings().setAppCacheEnabled(true); //enable app chache
                WebView.setSaveFromParentEnabled(true);
                WebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
                WebView.loadUrl("https://"+url);
                WebView.setWebViewClient(new Mybrowser());
                WebView.setDownloadListener(new DownloadListener() {
                    @Override
                    public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                        request.allowScanningByMediaScanner();
                        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);//notify online once download completed
                        final String fileName= URLUtil.guessFileName(url,contentDisposition,mimetype);
                        android.util.Log.d("Applog","fileName:"+fileName);
                        //request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"SurfIt_Downloads");
                        DownloadManager downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                        downloadManager.enqueue(request);
                    }
                });



                //this is for scanner (.)
               /* Scanner scanner = new Scanner(url);
                String rs = scanner.findInLine(".");
                if (rs == null){
                WebView.loadUrl("https://"+url);
                WebView.setWebViewClient(new Mybrowser());}
                else {
                    WebView.loadUrl("https://www.google.com/search?q="+url);

                }*/
            }
        });
    }

    public static class Mybrowser extends WebViewClient
    {
        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.proceed();
        }



        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.addbookmark:
                bm = new historydb(this);
                bm.AddBookmark(WebView.toString());
                Toast.makeText(this, "Bookmark Saved", Toast.LENGTH_LONG).show();
                return true;
            case R.id.newtab:
                Intent intent1 = new Intent(this,MainActivity.class);
                this.startActivity(intent1);
                return true;

            case R.id.private_window:
                Intent intent2 = new Intent(this,privateWindow.class);
                this.startActivity(intent2);
                return true;

            case    R.id.bookmark:
                Intent intent3 = new Intent(this, bookmarks.class);
                this.startActivity(intent3);
                return true;
            case R.id.history:
                Intent intent4 = new Intent(this, ShowHistory.class);
                this.startActivity(intent4);
                return true;
            case  R.id.setting:
                Intent intent5 = new Intent(this,Setting_Activity.class);
                this.startActivity(intent5);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // for back operation
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (event.getAction()==KeyEvent.ACTION_DOWN){
            switch (keyCode){
                case KeyEvent.KEYCODE_BACK:
                    if (WebView.canGoBack()){
                        WebView.goBack();
                    }
                    else {
                        finish();
                    }
                    return true;

            }
        }
        return super.onKeyDown(keyCode, event);
    }






}
