package com.example.apoorv.surfit;

public class HisAttrb {

    String history;
    String time;

    public HisAttrb(String history, String time) {

        this.history = history;
        this.time = time;

    }





    public String getHistory() {
        return history;
    }

    public String getTime() {
        return time;
    }
}
