package com.example.apoorv.surfit;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class historyshowadpt extends ArrayAdapter<HisAttrb> {

    Context hc;
    int layoutres;
    List<HisAttrb> hlist;
    public historyshowadpt(Context hc, int layoutres, List<HisAttrb> hlist){
        super(hc,layoutres,hlist);
        this.hc = hc;
        this.layoutres =layoutres;
        this.hlist= hlist;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(hc);
        View view = inflater.inflate(layoutres,null);
        //TextView idl = view.findViewById(R.id.idl);
        TextView hisl = view.findViewById(R.id.historyl);
        TextView time = view.findViewById(R.id.timel);
        HisAttrb historyget = hlist.get(position);


        hisl.setText(historyget.getHistory());
        time.setText( String.valueOf( historyget.getTime()));
        return  view;

    }

}
