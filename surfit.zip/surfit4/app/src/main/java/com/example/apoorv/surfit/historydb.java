package com.example.apoorv.surfit;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class historydb extends SQLiteOpenHelper {
    public static final String DB_NAME = "SurfIt_DB";
    private static final int DB_VERSION = 1;

    public historydb(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sqlhistory = "CREATE TABLE IF NOT EXISTS HISTORY( history VARCHAR,time DATETIME DEFAULT CURRENT_TIMESTAMP);";
        String sqlbookmark = "CREATE TABLE IF NOT EXISTS BOOKMARK( bookmark VARCHAR);";

        db.execSQL(sqlhistory);

    }

    public void AddBookmark(String bookm){
        SQLiteDatabase bookmark = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("bookmark",bookm);
        bookmark.insert("BOOKMARK",null,contentValues);
    }


    public void AddHistory(String his) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("history", his);
        db.insert("HISTORY", null, contentValues);
        db.close();

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int j) {
        String sqlhistory = "DROP TABLE IF EXISTS HISTORY";
        db.execSQL(sqlhistory);
        String sqlbookmrk = "DROP TABLE IF EXISTS BOOKMARK";
        db.execSQL(sqlbookmrk);
        onCreate(db);


    }
}
