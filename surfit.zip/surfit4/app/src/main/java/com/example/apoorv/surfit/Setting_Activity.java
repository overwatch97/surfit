package com.example.apoorv.surfit;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.File;

public class Setting_Activity extends AppCompatActivity {
TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        textView = (TextView) findViewById(R.id.crlche);
        setContentView(R.layout.activity_setting_);

    }
    public void perform_action(View v)
    {
        TextView tv= (TextView) findViewById(R.id.crlche);
        Intent intent = new Intent(this,Clear_Cache.class);
        this.startActivity(intent);
    }
    public void aboutus_settings(View view)
    {
        TextView tv= (TextView) findViewById(R.id.aboutus_surfit);
        Intent intent = new Intent(this,about_surfit.class);
        this.startActivity(intent);

    }



}
