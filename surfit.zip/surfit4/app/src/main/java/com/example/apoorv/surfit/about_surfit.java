package com.example.apoorv.surfit;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import static com.example.apoorv.surfit.R.id.aboutWeb;

public class about_surfit extends AppCompatActivity {
    private android.webkit.WebView WebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_surfit);
        WebView = (android.webkit.WebView) findViewById(R.id.aboutWeb);
        WebView.loadUrl("file:///android_asset/about.html");
    }
}
