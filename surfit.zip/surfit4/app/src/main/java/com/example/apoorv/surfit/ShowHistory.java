
package com.example.apoorv.surfit;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class ShowHistory extends AppCompatActivity {
    SQLiteDatabase ShowHistoryDb;
    List<HisAttrb> HistoryList;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_history);
        ShowHistoryDb= openOrCreateDatabase(historydb.DB_NAME,MODE_PRIVATE,null);
        HistoryList = new ArrayList<>();
        listView = findViewById(R.id.listv);
        loaddb();
    }
    private void loaddb(){
        String sql = "SELECT * FROM HISTORY";
        @SuppressLint("Recycle") Cursor cursor = ShowHistoryDb.rawQuery(sql,null);
        if (cursor.moveToFirst()){
            do{
                HistoryList.add(new HisAttrb(
                        cursor.getString(0)
                        ,
                        cursor.getString(1)
                ));

            }
            while (cursor.moveToNext());
            historyshowadpt adpt = new historyshowadpt(this,R.layout.list_layout,HistoryList);
            listView.setAdapter(adpt);

        }


    }





}
